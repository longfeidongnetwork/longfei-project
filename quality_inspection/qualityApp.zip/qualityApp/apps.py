from django.apps import AppConfig


class QualityappConfig(AppConfig):
    name = 'qualityApp'
