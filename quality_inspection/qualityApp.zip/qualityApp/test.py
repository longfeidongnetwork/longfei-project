#!/usr/bin/env python
# _*_ coding:utf-8 _*_
"""
@time: 2021/3/11 14:26
@author:donglongfei
@file: test.py
"""

storage={}

storage['first']={}
print(storage)
storage['first'].setdefault('Grace',[]).append('sister')
print(storage)
tian='tian'
storage['first'].setdefault('Grace',[]).append(tian)

# print(r is storage['first']['Grace'])
print(storage)